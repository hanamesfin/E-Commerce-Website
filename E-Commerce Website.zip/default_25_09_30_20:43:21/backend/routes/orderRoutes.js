import express from 'express';
import { body, param } from 'express-validator';

import {
  createOrder,
  getUserOrders,
  getOrderById,
  stripeWebhookHandler,
} from '../controllers/orderController.js';

import { protectUser } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post(
  '/',
  protectUser,
  [
    body('items')
      .isArray({ min: 1 })
      .withMessage('Order must contain at least one item'),
    body('items.*.productId').isMongoId().withMessage('Valid productId required'),
    body('items.*.quantity')
      .isInt({ min: 1 })
      .withMessage('Quantity must be at least 1'),
    body('couponCode').optional().isString(),
    body('shippingAddress').notEmpty().withMessage('Shipping address is required'),
  ],
  createOrder
);

router.get('/user', protectUser, getUserOrders);

router.get('/:id', protectUser, [param('id').isMongoId()], getOrderById);

// Stripe webhook endpoint - raw body required, so no JSON parser here
router.post('/webhook', express.raw({ type: 'application/json' }), stripeWebhookHandler);

export default router;
