import express from 'express';

import { getAnalytics } from '../controllers/adminController.js';
import { protectAdmin } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/analytics', protectAdmin, getAnalytics);

export default router;
