import express from 'express';
import { body, param, query } from 'express-validator';

import {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
} from '../controllers/productController.js';

import { protectAdmin } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get(
  '/',
  [
    query('category').optional().isString(),
    query('priceMin').optional().isFloat({ min: 0 }),
    query('priceMax').optional().isFloat({ min: 0 }),
    query('sortBy').optional().isIn(['price', 'name']),
    query('sortOrder').optional().isIn(['asc', 'desc']),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
  ],
  getProducts
);

router.get('/:id', [param('id').isMongoId()], getProductById);

router.post(
  '/',
  protectAdmin,
  [
    body('name').trim().notEmpty().withMessage('Product name is required'),
    body('description').optional().trim(),
    body('price').isFloat({ min: 0 }).withMessage('Price must be positive number'),
    body('category').optional().trim(),
    body('imageUrl').optional().isURL().withMessage('Image URL must be valid'),
    body('stock').optional().isInt({ min: 0 }),
  ],
  createProduct
);

router.put(
  '/:id',
  protectAdmin,
  [
    param('id').isMongoId(),
    body('name').optional().trim().notEmpty(),
    body('description').optional().trim(),
    body('price').optional().isFloat({ min: 0 }),
    body('category').optional().trim(),
    body('imageUrl').optional().isURL(),
    body('stock').optional().isInt({ min: 0 }),
  ],
  updateProduct
);

router.delete('/:id', protectAdmin, [param('id').isMongoId()], deleteProduct);

export default router;
