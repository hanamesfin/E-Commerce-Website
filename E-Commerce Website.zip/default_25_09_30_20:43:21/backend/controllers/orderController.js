import { validationResult } from 'express-validator';
import Stripe from 'stripe';
import mongoose from 'mongoose';

import Order from '../models/Order.js';
import Product from '../models/Product.js';
import Coupon from '../models/Coupon.js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const createOrder = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  try {
    const { items, couponCode, shippingAddress } = req.body;
    const userId = req.user._id;

    // Fetch product prices and check stock
    const productIds = items.map((item) => item.productId);
    const products = await Product.find({ _id: { $in: productIds } });

    if (products.length !== productIds.length) {
      return res.status(400).json({ message: 'One or more products not found' });
    }

    let totalPrice = 0;
    const orderItems = [];

    for (const item of items) {
      const product = products.find((p) => p._id.toString() === item.productId);

      if (!product) {
        return res.status(400).json({ message: `Product not found: ${item.productId}` });
      }
      if (product.stock < item.quantity) {
        return res.status(400).json({ message: `Not enough stock for product: ${product.name}` });
      }
      const itemPrice = product.price * item.quantity;
      totalPrice += itemPrice;
      orderItems.push({
        product: product._id,
        quantity: item.quantity,
        price: product.price,
      });
    }

    let discount = 0;
    let coupon = null;
    if (couponCode) {
      coupon = await Coupon.findOne({ code: couponCode.toUpperCase() });
      if (!coupon) {
        return res.status(400).json({ message: 'Invalid coupon code' });
      }
      if (coupon.expiresAt && coupon.expiresAt < new Date()) {
        return res.status(400).json({ message: 'Coupon expired' });
      }
      if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
        return res.status(400).json({ message: 'Coupon usage limit reached' });
      }
      discount = (totalPrice * coupon.discountPercent) / 100;
      totalPrice -= discount;
    }

    // Create Stripe PaymentIntent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(totalPrice * 100), // amount in cents
      currency: 'usd',
      metadata: { userId: userId.toString() },
    });

    // Create order with status pending
    const order = new Order({
      user: userId,
      items: orderItems,
      totalPrice,
      couponCode: couponCode ? couponCode.toUpperCase() : undefined,
      status: 'pending',
      paymentIntentId: paymentIntent.id,
    });

    // Reduce stock quantity for each product
    for (const item of orderItems) {
      await Product.findByIdAndUpdate(item.product, { $inc: { stock: -item.quantity } });
    }

    if (coupon) {
      coupon.usedCount += 1;
      await coupon.save();
    }

    await order.save();

    res.status(201).json({ orderId: order._id, clientSecret: paymentIntent.client_secret });
  } catch (err) {
    res.status(500).json({ message: err.message || 'Server error' });
  }
};

const getUserOrders = async (req, res) => {
  try {
    const userId = req.user._id;
    const orders = await Order.find({ user: userId }).populate('items.product').sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: err.message || 'Server error' });
  }
};

const getOrderById = async (req, res) => {
  try {
    const orderId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(orderId)) {
      return res.status(400).json({ message: 'Invalid order ID' });
    }

    const order = await Order.findById(orderId).populate('items.product');
    if (!order) return res.status(404).json({ message: 'Order not found' });

    // Check ownership or admin
    if (!order.user.equals(req.user._id) && !req.user.isAdmin) {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json(order);
  } catch (err) {
    res.status(500).json({ message: err.message || 'Server error' });
  }
};

// Stripe webhook for payment confirmation
const stripeWebhookHandler = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Stripe webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'payment_intent.succeeded') {
    const paymentIntent = event.data.object;
    try {
      const order = await Order.findOne({ paymentIntentId: paymentIntent.id });
      if (order && order.status !== 'paid') {
        order.status = 'paid';
        await order.save();
        console.log(`Order ${order._id} marked as paid.`);
      }
    } catch (err) {
      console.error('Error updating order status on payment:', err.message);
      return res.status(500).send();
    }
  }

  res.json({ received: true });
};

export { createOrder, getUserOrders, getOrderById, stripeWebhookHandler };
