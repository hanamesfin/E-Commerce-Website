import Order from '../models/Order.js';
import User from '../models/User.js';
import Product from '../models/Product.js';

const getAnalytics = async (req, res) => {
  try {
    // Total sales amount (sum of paid orders)
    const totalSalesAggregate = await Order.aggregate([
      { $match: { status: 'paid' } },
      { $group: { _id: null, totalSales: { $sum: '$totalPrice' } } },
    ]);
    const totalSales = totalSalesAggregate[0]?.totalSales || 0;

    // Monthly revenue for past 6 months
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
    const monthlyRevenue = await Order.aggregate([
      { $match: { status: 'paid', createdAt: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
          revenue: { $sum: '$totalPrice' },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ]);

    // User registrations count
    const userRegistrations = await User.countDocuments();

    // Best-selling products by quantity sold
    const bestSellingProducts = await Order.aggregate([
      { $match: { status: 'paid' } },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.product',
          totalQuantity: { $sum: '$items.quantity' },
        },
      },
      { $sort: { totalQuantity: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: 'products',
          localField: '_id',
          foreignField: '_id',
          as: 'product',
        },
      },
      { $unwind: '$product' },
      {
        $project: {
          _id: 0,
          productId: '$_id',
          name: '$product.name',
          totalQuantity: 1,
          price: '$product.price',
          imageUrl: '$product.imageUrl',
        },
      },
    ]);

    res.json({
      totalSales,
      monthlyRevenue,
      userRegistrations,
      bestSellingProducts,
    });
  } catch (err) {
    res.status(500).json({ message: err.message || 'Server error' });
  }
};

export { getAnalytics };
